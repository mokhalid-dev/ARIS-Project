package h.eit.dr.android.aris_project;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


import com.google.firebase.auth.FirebaseAuth;

public class ArisRequestPage extends AppCompatActivity {

    Button btn_logout,btn_source,btn_destination,btn_mat,btn_submit;
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    TextView txt_hello;
    View toDisplayInDialog;
    AlertDialog.Builder sourcePopup,destinationPopup,matPopup;
    RadioGroup radioGroupLocation,radioGroupMat;

    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }




        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_aris_request_page);


            btn_source = (Button) findViewById(R.id.btn_source);
            btn_destination = (Button) findViewById(R.id.btn_destination);
            btn_mat = (Button) findViewById(R.id.btn_mat);
            btn_submit = (Button) findViewById(R.id.btn_submit);
            btn_logout = (Button) findViewById(R.id.btn_logout);
            txt_hello = (TextView) findViewById(R.id.txt_hello);

            txt_hello.setText("Hello,...");

            mAuth = FirebaseAuth.getInstance();
            mAuthListener = new FirebaseAuth.AuthStateListener() {
                @Override
                public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                    if(firebaseAuth.getCurrentUser() == null){
                        startActivity(new Intent(ArisRequestPage.this,LoginPage.class));
                    }
                }
            };


           btn_logout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mAuth.signOut(); }});

           btn_source.setOnClickListener(new View.OnClickListener(){
               @Override
               public void onClick(View v) {
                   sourceButtonClick(); }});

            btn_destination.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    destinationClick(); }});

            btn_mat.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    materialClick(); }});
        }

        public void sourceButtonClick(){

            toDisplayInDialog=getLayoutInflater().inflate(R.layout.radiogroup,null);
            sourcePopup = new AlertDialog.Builder(ArisRequestPage.this);
            sourcePopup.setTitle("Source Location");
            sourcePopup.setIcon(R.drawable.logorequest);
            sourcePopup.setView(toDisplayInDialog);
            sourcePopup.setNeutralButton("Cancel",null);
            sourcePopup.setPositiveButton("Set Source", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    rGSourceClick();
                }
            });
            sourcePopup.show();
        }

        public void destinationClick(){

            toDisplayInDialog=getLayoutInflater().inflate(R.layout.radiogroup,null);
            destinationPopup = new AlertDialog.Builder(ArisRequestPage.this);
            destinationPopup.setTitle("Destination Location");
            destinationPopup.setIcon(R.drawable.logorequest);
            destinationPopup.setView(toDisplayInDialog);
            destinationPopup.setNeutralButton("Cancel",null);
            destinationPopup.setPositiveButton("Set Destination", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    rGDestinationClick();
                }
            });
            destinationPopup.show();
        }

   public void rGSourceClick(){
       radioGroupLocation = (RadioGroup)
               toDisplayInDialog.findViewById(R.id.radioGroupLocation);
       int radioGroupId = radioGroupLocation.getCheckedRadioButtonId();
       RadioButton myCheckedSourceButton = (RadioButton)
               toDisplayInDialog.findViewById(radioGroupId);
       int index = radioGroupLocation.indexOfChild(myCheckedSourceButton);

       switch(index) {

           case 0:
               myCheckedSourceButton.isChecked();
               btn_source.setText("Room 1");
               Toast.makeText(getApplicationContext(),"Room 1 selected",Toast.LENGTH_SHORT).show();
               break;

           case 1:
               myCheckedSourceButton.isChecked();
               btn_source.setText("Room 2");
               Toast.makeText(getApplicationContext(),"Room 2 selected",Toast.LENGTH_SHORT).show();
               break;

           case 2:
               myCheckedSourceButton.isChecked();
               btn_source.setText("Room 3");
               Toast.makeText(getApplicationContext(),"Room 3 selected",Toast.LENGTH_SHORT).show();
               break;

       }


   }
        public void rGDestinationClick(){
            radioGroupLocation = (RadioGroup)
                    toDisplayInDialog.findViewById(R.id.radioGroupLocation);
            int radioGroupId = radioGroupLocation.getCheckedRadioButtonId();
            RadioButton myCheckedDestinationButton = (RadioButton)
                    toDisplayInDialog.findViewById(radioGroupId);
            int index = radioGroupLocation.indexOfChild(myCheckedDestinationButton);

            switch(index) {

                case 0:
                    myCheckedDestinationButton.isChecked();
                    btn_destination.setText("Room 1");
                    Toast.makeText(getApplicationContext(),"Room 1 selected",Toast.LENGTH_SHORT).show();
                    break;

                case 1:
                    myCheckedDestinationButton.isChecked();
                    btn_destination.setText("Room 2");
                    Toast.makeText(getApplicationContext(),"Room 2 selected",Toast.LENGTH_SHORT).show();
                    break;

                case 2:
                    myCheckedDestinationButton.isChecked();
                    btn_destination.setText("Room 3");
                    Toast.makeText(getApplicationContext(),"Room 3 selected",Toast.LENGTH_SHORT).show();
                    break;

            }
        }


        public void materialClick(){

            toDisplayInDialog=getLayoutInflater().inflate(R.layout.radiogroupmaterial,null);
            matPopup = new AlertDialog.Builder(ArisRequestPage.this);
            matPopup.setTitle("Choose Material");
            matPopup.setIcon(R.drawable.logorequest);
            matPopup.setView(toDisplayInDialog);
            matPopup.setNeutralButton("Cancel",null);
            matPopup.setPositiveButton("Set Material", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    rGMatClick();
                }
            });
            matPopup.show();
        }


        public void rGMatClick(){
            radioGroupMat = (RadioGroup)
                    toDisplayInDialog.findViewById(R.id.radioGroupMat);
            int radioGroupId = radioGroupMat.getCheckedRadioButtonId();
            RadioButton myCheckedMatButton = (RadioButton)
                    toDisplayInDialog.findViewById(radioGroupId);
            int index = radioGroupMat.indexOfChild(myCheckedMatButton);

            switch(index) {

                case 0:
                    myCheckedMatButton.isChecked();
                    btn_mat.setText("Material A");
                    Toast.makeText(getApplicationContext(),"Material A selected",Toast.LENGTH_SHORT).show();
                    break;

                case 1:
                    myCheckedMatButton.isChecked();
                    btn_mat.setText("Material B");
                    Toast.makeText(getApplicationContext(),"Material B selected",Toast.LENGTH_SHORT).show();
                    break;

                case 2:
                    myCheckedMatButton.isChecked();
                    btn_mat.setText("Material C");
                    Toast.makeText(getApplicationContext(),"Material C selected",Toast.LENGTH_SHORT).show();
                    break;

            }

        }
    }


